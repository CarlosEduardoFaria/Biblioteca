
package calculadora;

public abstract class OperacaoMatematica {

    double num1, num2;
    
public abstract double Calcular (double n1, double n2);
}