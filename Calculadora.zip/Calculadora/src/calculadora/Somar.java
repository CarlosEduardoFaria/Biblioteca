package calculadora;


public class Somar extends OperacaoMatematica {
    public double Calcular(double n1, double n2) {
        return n1 + n2;
    }
}
