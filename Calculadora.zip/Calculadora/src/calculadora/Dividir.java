package calculadora;


public class Dividir extends OperacaoMatematica {
    public double Calcular(double n1, double n2) {
        return n1 / n2;
    }
}
